# Build Your Own World Design Document

**Partner 1:**

**Partner 2:**

## Classes and Data Structures

## Algorithms

## Persistence
